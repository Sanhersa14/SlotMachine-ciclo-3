
/**
 * Clase que se encarga del tema de los colores de los simbolos.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Symbol
{
    private String color;
    
    public Symbol(String color){
        this.color = color; //Se asigna un color en el constructor
    }
    
    /**
     * Obtiene el color actual del simbolo
     * 
     * @return String color del simbolo
     */
    public String getColor(){
        return color;
    }
    
    /**
     * Asigna un color al simbolo
     * 
     * @param String color a asignar al simbolo
     */
    public void setColor(String color){
        this.color = color; //Cambia el color de un śimbolo cuantas veces se quiera
    }
}