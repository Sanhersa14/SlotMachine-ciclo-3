

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


/**
 * Pruebas de unidad del ciclo 2 para SlotMachine.
 * Todas las pruebas corren en modo invisible.
 *
 * @author (Wilmar Beltran, Santiago Hernández)
 * @version (ciclo 2)
 */
public class SlotMachineC2Test {

    private SlotMachine sm;

    @BeforeEach
    public void setUp(){
        sm = new SlotMachine();
        sm.makeInvisible(); // por defecto ya nace invisible, pero lo dejamos explícito
    }

    // ---------- swap ----------
    @Test
    public void swapShouldExchangeMountedAndVisibleSymbolsBetweenTwoWheels(){
        sm.addWheel(1);
        sm.addWheel(2);
        sm.addSymbol(1, "red");
        sm.addSymbol(2, "blue");
        sm.placeSymbol(1, "red");
        sm.placeSymbol(2, "blue");
        sm.spin(new String[]{"red", "blue"});

        sm.swap(1, 2);

        String[] config = sm.configuration();
        assertTrue(sm.ok());
        assertEquals("blue", config[0]);
        assertEquals("red", config[1]);
    }
    
    @Test
    public void swapShouldFailWhenAWheelDoesNotExist(){
        sm.addWheel(1);

        sm.swap(1, 5); // la rueda 5 no existe

        assertFalse(sm.ok());
    }

    // ---------- lock / unlock ----------
    
    @Test
    public void lockShouldPreventWheelFromSpinning(){
        sm.addWheel(1);
        sm.addSymbol(1, "red");
        sm.addSymbol(1, "green");
        sm.placeSymbol(1, "red");
        sm.placeSymbol(1, "green");
        sm.spin(new String[]{"red"});

        sm.lock(1);
        sm.spin(1, 1); // intenta avanzar un paso estando bloqueada

        assertFalse(sm.ok());
        assertEquals("red", sm.configuration()[0]); // no debió cambiar
    }
    
    @Test
    public void unlockShouldAllowWheelToSpinAgain(){
        sm.addWheel(1);
        sm.addSymbol(1, "red");
        sm.addSymbol(1, "green");
        sm.placeSymbol(1, "red");
        sm.placeSymbol(1, "green");
        sm.spin(1, 0);

        sm.lock(1);
        sm.unlock(1);
        sm.spin(1, 1);

        assertTrue(sm.ok());
        assertEquals("green", sm.configuration()[0]);
    }
    
    @Test
    public void lockShouldFailWhenWheelDoesNotExist(){
        sm.lock(3); // no hay ninguna rueda creada

        assertFalse(sm.ok());
    }

    // ---------- spin(wheel, steps) ----------
    
    @Test
    public void spinWithStepsShouldAdvanceCircularlyThroughMountedSymbols(){
        sm.addWheel(1);
        sm.addSymbol(1, "red");
        sm.addSymbol(1, "green");
        sm.addSymbol(1, "blue");
        sm.placeSymbol(1, "red");
        sm.placeSymbol(1, "green");
        sm.placeSymbol(1, "blue");
        sm.spin(1, 0); // arranca en "red" (primer símbolo montado)

        sm.spin(1, 4); // avanza 4 pasos sobre 3 símbolos: red->green->blue->red->green

        assertTrue(sm.ok());
        assertEquals("green", sm.configuration()[0]);
    }

    @Test
    public void spinWithStepsShouldFailOnEmptyWheel(){
        sm.addWheel(1); // sin símbolos montados

        sm.spin(1, 2);

        assertFalse(sm.ok());
    }

    // ---------- spin(setSymbols[]) ----------
    
    @Test
    public void spinWithConfigurationShouldSetExactColorsRequested(){
        sm.addWheel(1);
        sm.addWheel(2);
        sm.addSymbol(1, "red");
        sm.addSymbol(2, "blue");

        sm.spin(new String[]{"red", "blue"});

        assertTrue(sm.ok());
        assertArrayEquals(new String[]{"red", "blue"}, sm.configuration());
    }

    @Test
    public void spinWithConfigurationShouldFailWhenArraySizeDoesNotMatchWheelCount(){
        sm.addWheel(1);
        sm.addWheel(2);
        sm.addSymbol(1, "red");

        sm.spin(new String[]{"red"}); // solo 1 color para 2 ruedas

        assertFalse(sm.ok());
    }
    
    @Test
    public void spinWithConfigurationShouldFailWhenColorDoesNotExistInCatalog(){
        sm.addWheel(1);
        sm.addSymbol(1, "red");

        sm.spin(new String[]{"purple"}); // "purple" no está en el catálogo

        assertFalse(sm.ok());
    }
}