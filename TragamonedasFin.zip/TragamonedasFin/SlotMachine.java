
/**
 * Slot Machine
 * 
 * @author (Wilmar Beltran, Santiago Hernández) 
 * @version (6 september 2026)
 */
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class SlotMachine implements TestingTool{
    private boolean verify;
    private ArrayList<Wheel> wheels;
    private ArrayList<Symbol> symbols;
    private Canvas canvas;
    private boolean isVisible;
    private ArrayList<Circle> windows; //Es para hacer una "ventana circular" por cada rueda de la maquina
    
    /**
     * Constructor de la clase SlotMachine.
     */
    public SlotMachine(){
        verify = true;
        wheels = new ArrayList<>();
        symbols = new ArrayList<>();
        canvas = Canvas.getCanvas();
        windows = new ArrayList<>();
    }
    
    /**
     * Consulta si la última operación ejecutada en la máquina fue exitosa.
     * 
     * @return true si la última acción fue válida, false en caso contrario.
     */
    public boolean ok(){
        return verify;
    }
    
    /**
     * Finaliza de forma inmediata la ejecución del programa.
     */
    public void exit(){
        System.exit(0); //Salir del programa correctamente  
    }
    
    /**
     * Añade una nueva rueda vacía a la máquina en la posición especificada.
     * Ajusta la posición a los límites válidos si el valor ingresado se sale de rango.
     * 
     * @param pos Posición donde se insertará la rueda
     */
    public void addWheel(int pos){
        int idx;
        if (pos <= 1){
            idx = 0; //Si pos es menor o igual a 1 entonces lo que hacemos es colocar la wheel al inicio
        }
        else if (pos - 1 > wheels.size()){
            idx = wheels.size(); //Si la posicion se sale del tamaño de wheels entonces colocamos al final la wheel
        }
        else{
            idx = pos - 1; //Agregar la wheel en donde el usuario quiere
        }
        wheels.add(idx, new Wheel());
        verify = true;
        if (isVisible){ //Redibujamos si nuestra maquina es visible
            draw();
        }
    }
    
    /**
     * Elimina una rueda de la máquina según la posición indicada.
     * Controla las posiciones extremas para evitar errores de índice.
     * 
     * @param pos Posición de la rueda que se desea eliminar
     */
    public void delWheel(int pos){
        if (wheels.size() == 0){ //Si no hay ruedas por eliminar entonces no se puede hacer nada
            verify = false;
            mostrarError("No hay ruedas para eliminar.");
        }
        else{
            int idx;
            if (pos <= 1) {
                idx = 0; //Elegimos la primera rueda si la posicion es menor o igual a 1
            } 
            else if (pos > wheels.size()) {
                idx = wheels.size() - 1; // Si la posicion se pasa del límite seleccionamos la ultima rueda
            } 
            else { 
                idx = pos - 1; //Seleccionamos la posicion que quiere el usuario (obviamente restamos 1 porque aca se arranca desde idx0)
            }
            wheels.remove(idx); //Borramos la rueda seleccionada anteriormente
            verify = true;
            if (isVisible){ //Redibujamos si nuestra maquina es visible
                draw();
            }
        }
    }
    
    /**
     * Crea un nuevo símbolo con un color dado y lo agrega al catálogo general de la máquina.
     * 
     * @param pos Posición en la que se insertará la ficha en el catálogo
     * @param color Nombre del color para el nuevo símbolo
     */
    public void addSymbol(int pos, String color){
        Symbol newSymbol = new Symbol(color);
        if (pos <= 1){
            symbols.add(0, newSymbol); 
        }
        else if (pos - 1 > symbols.size()){
            symbols.add(newSymbol); //Agragamos al ArrayList el símbolo
        }
        else{
            symbols.add(pos - 1, newSymbol);
        }
        verify = true;
    }
    
    /**
     * Elimina un símbolo del catálogo general buscando por su color.
     * 
     * @param symbol Color del símbolo que se desea eliminar
     */
    public void delSymbol(String symbol){
        verify = false; //Como aun no sabemos si la ficha ingresada por el usuario realmente existe
    
        for (int i = 0; i < symbols.size(); i++) {
            Symbol ficha = symbols.get(i); // Sacamos la ficha de la casilla i para analizar
            String colorFicha = ficha.getColor(); // Miramos el color que tiene
            if (colorFicha.equals(symbol)) { // Comparamos los colores
                symbols.remove(i); 
                verify = true; 
                break;
            }
        }
        
        if (!verify) {
            mostrarError("El símbolo " + symbol + " no existe en el catalogo.");
        }
    }
    
    /**
     * Coloca un símbolo del catálogo general dentro de una rueda especificada.
     * 
     * @param wheel Número de la rueda donde se coloca el símbolo
     * @param symbol Color de la ficha que se quiere montar en la rueda
     */
    public void placeSymbol(int wheel, String symbol){
        verify = false; 
        boolean ruedaExiste = false; 
        if (wheel >= 1 && wheel <= wheels.size()){
            ruedaExiste = true;
        }
        
        boolean simboloExiste = false; 
        Symbol simboloEncontrado = null; //Esta variable nos sirve para guardar la ficha exacta si la encontramos
        for (int j = 0; j < symbols.size(); j++){
            Symbol ficha = symbols.get(j); //Sacamos la ficha del ArrayList
            String colorFicha = ficha.getColor(); //Miramos el color que tiene
            if (colorFicha.equals(symbol)){ //Comparamos los colores
                simboloExiste = true; 
                simboloEncontrado = ficha; 
                break; 
            }
        }
        
        if (ruedaExiste && simboloExiste){
            verify = true;
            wheels.get(wheel - 1).mountSymbol(simboloEncontrado); //Añadimos la ficha dentro de la rueda (va con -1 porque los indices en java van desde 0)
        }
        
        else{
            mostrarError("No se pudo montar el simbolo: Verifique que la rueda y el simbolo existan.");
        }
    }
    
    /**
     * Gira una rueda específica seleccionando una ficha al azar y la coloca en la ventanilla frontal.
     * 
     * @param wheel Número de la rueda a girar
     */
    public void spin(int wheel) {
        if (wheel < 1 || wheel > wheels.size()) { 
            verify = false; 
            mostrarError("La rueda " + wheel + " no existe.");
            return;
        }
        
        Wheel rueda = wheels.get(wheel - 1);
        boolean pudoGirar = rueda.rotate();
        if (pudoGirar) {
            verify = true;
            if (isVisible){ //Redibujamos si nuestra maquina es visible
                draw();
            }
        }
        
        else{
            if (rueda.isLocked()){
                mostrarError("La rueda no pudo girar porque esta bloqueada");
            }
            else{
                mostrarError("La rueda que se quiere girar no tiene simbolos montados");
            }
            verify = false;
        }
    }
    
    /**
     * Gira de forma consecutiva todas las ruedas disponibles en la máquina.
     */
    public void spin() {
        boolean aok = true; //Utilizamos una bandera temporal para verificar que todas las ruedas giran correctamente
        for (int k = 1; k <= wheels.size(); k++) {
            spin(k); //Aca reultilizamos el método para poder girar todoas las ruedas disponibles
            if (!verify) {
                aok = false; //Si alguna rueda falla que podria ser por ejemplo porque esta vacia, entonces el giro no es valido.
            }
        }
        verify = aok; //Dependiendo de la variable aok, el estado final de la máquina seria exitoso si todo sale bien.
    }
    
    /**
     * Retorna un arreglo con los colores de todos los símbolos que existen en el catálogo
     * general de la máquina, en el orden en que fueron agregados.
     * 
     * @return Arreglo de cadenas de texto con los colores del catálogo de símbolos
     */
    public String[] symbols() {
        String[] result = new String[symbols.size()]; //Creamos un arreglo del mismo tamaño que el catálogo de símbolos

        for (int i = 0; i < symbols.size(); i++) {
            Symbol ficha = symbols.get(i); //Sacamos la ficha en la posición i del catálogo
            result[i] = ficha.getColor(); //Guardamos su color en el arreglo de resultado
        }

        verify = true;
        return result;
    }
    
    /**
     * Cuenta la cantidad de símbolos distintos que se encuentran visibles en la ventanilla.
     * 
     * @return Número de colores únicos en la ventanilla frontal
     */
    public int distinctSymbols() {
        String[] current = configuration(); // Traemos los símbolos actuales
        int uniqueCount = 0; // Contador de símbolos únicos
        ArrayList<String> vistos = new ArrayList<>();
        
        for (int i = 0; i < current.length; i++){ //Añadimos al ArrayList los simbolos que no son duplicados en current
            if (current[i] != null){
                if (!vistos.contains(current[i])){
                    vistos.add(current[i]);
                }
            }
        }
        uniqueCount = vistos.size();
        verify = true;
        return uniqueCount;
    }
    
    /**
    * Retorna un arreglo con los colores de los símbolos actualmente visibles en cada
    * rueda de la máquina, ordenados de izquierda a derecha.
    * 
    * @return Arreglo de cadenas de texto con los colores visibles por rueda
    */
    public String[] configuration() {
        String[] result = new String[wheels.size()]; //Creamos un arreglo con una casilla por cada rueda de la máquina

        for (int i = 0; i < wheels.size(); i++) {
            result[i] = wheels.get(i).getVisibleColor();
        }

        verify = true;
        return result;
    }
    
    /**
     * Hace visible la representación gráfica de la máquina tragaperras en el lienzo.
     */
    public void makeVisible(){
        isVisible = true;
        draw();
        verify = true;
    }
    
    /**
     * Oculta la representación gráfica de la máquina tragaperras en el lienzo.
     */
    public void makeInvisible(){
        erase();
        isVisible = false;
        verify = true;
    }
    
    /**
    * Dibuja una ventana circular por cada rueda de la máquina, ubicada de izquierda
    * a derecha, mostrando el color visible actual de esa rueda. Si la máquina está
    * en estado ganador (jackpot), las ventanas se muestran de mayor tamaño.
    */
    private void draw(){
        //Borramos las ventanas anteriores antes de redibujar
        for (int i = 0; i < windows.size(); i++) {
            Circle viejo = windows.get(i);
            viejo.makeInvisible();
        }
        windows = new ArrayList<Circle>();

        String[] current = configuration(); //Traemos el color visible de cada rueda

        int size = 40; //Tamaño normal de las ventanas
        if (isJackpot()) {
            size = 60; //Si hay jackpot, las ventanas se ven mas grandes
        }

        for (int i = 0; i < wheels.size(); i++) {
            Circle c = new Circle();
            c.changeSize(size);
            c.moveHorizontal(i * 60); //Separamos cada ventana 60 pixeles de la anterior

            String colorActual = current[i];
            if (colorActual == null) {
                colorActual = "black"; //Negro si aun no se ha girado esa rueda (en blanco se perdia todo con el fondo)
            }
            c.changeColor(colorActual);

            c.makeVisible();
            windows.add(c);
        }
    }

    /**
    * Oculta todas las ventanas visuales de la máquina.
    */
    private void erase(){
        for (int i = 0; i < windows.size(); i++) {
            Circle c = windows.get(i);
            c.makeInvisible();
        }
    }
    
    /**
    * Consulta si la configuración actual de símbolos visibles corresponde a un estado ganador.
    * Solo puede haber jackpot si todas las ruedas ya se giraron (ninguna en null) y todas
    * muestran el mismo color.
    * 
    * @return true si todas las ruedas están giradas y muestran el mismo color, false en caso contrario.
    */
    public boolean isJackpot(){
        String[] current = configuration();
    
        for (int i = 0; i < current.length; i++) {
            if (current[i] == null) {
                return false; //Si alguna rueda no se ha girado todavia, no puede haber jackpot
            }
        }
    
        int contSymbols = distinctSymbols();
        if (contSymbols == 1) {
            return true;
        }
        else{
            return false;
        }
    }
    
    /**
    * Muestra un mensaje de error al usuario mediante un JOptionPane, pero solo
    * si el simulador está actualmente visible.
    * 
    * @param mensaje Texto del mensaje que se le quiere mostrar al usuario
    */
    private void mostrarError(String mensaje){
        if (isVisible) { //Solo mostramos el mensaje si el simulador esta visible
            JOptionPane.showMessageDialog(null, mensaje);
        }
    }
    
    /**
    * Intercambia la posicion de dos ruedas de la maquina
    * Falla si alguna de las dos ruedas no existe.
    * 
    * @param wheel1 Número de la primera rueda
    * @param wheel2 Número de la segunda rueda
    */
    public void swap(int wheel1, int wheel2){
        if (wheel1 < 1 || wheel1 > wheels.size() || wheel2 < 1 || wheel2 > wheels.size()){
            verify = false;//Alguna de las ruedas solicitadas por el usuario no existe
            mostrarError("Una de las ruedas indicadas no existe.");
            return;
        }
    
        int idx1 = wheel1 - 1;
        int idx2 = wheel2 - 1;
        
        Wheel temp = wheels.get(idx1);
        wheels.set(idx1, wheels.get(idx2));
        wheels.set(idx2, temp);
        verify = true;
    
        if (isVisible){
            draw(); // solo redibuja el resultado final, no hay pasos intermedios que animar
        }
    }
    
    /**
    * Bloquea una rueda para que no pueda girar ni avanzar.
    * Falla si la rueda no existe.
    *
    * @param wheel Número de la rueda que se quiere bloquear
    */
    public void lock(int wheel){
        if (wheel < 1 || wheel > wheels.size()) { 
            verify = false; //La rueda solicitada por el usuario no existe
            mostrarError("La rueda " + wheel + " no existe.");
            return;
        }
        wheels.get(wheel - 1).lock();
        verify = true;
        
    }
    
    /**
    * Desbloquea una rueda para que pueda volver a girar.
    * Falla si la rueda no existe.
    *
    * @param wheel Número de la rueda que se quiere desbloquear
    */
    public void unlock(int wheel){
        if (wheel < 1 || wheel > wheels.size()) { 
            verify = false; //La rueda solicitada por el usuario no existe
            mostrarError("La rueda " + wheel + " no existe.");
            return;
        }
        
        wheels.get(wheel - 1).unlock();
        verify = true;
    }
    
    /**
    * Avanza una rueda el número de pasos indicado, mostrando cada paso si la máquina es visible. 
    * Falla si la rueda no existe, está bloqueada o está vacía.
    * 
    * @param wheel Número de la rueda a avanzar
    * @param steps Cantidad de posiciones que avanza la rueda
    */
    public void spin(int wheel, int steps){
        if (wheel < 1 || wheel > wheels.size()) { 
            verify = false; //La rueda solicitada por el usuario no existe
            mostrarError("La rueda " + wheel + " no existe.");
            return;
        }
        
        Wheel rueda = wheels.get(wheel - 1);
        for (int i = 1; i <= steps; i++){
            boolean valido = rueda.advance();
            if (valido){
                if (isVisible){
                    draw();
                    canvas.wait(300); //Espera 300 milisegundos entre paso y paso para mostrar el movimiento
                }
            }
            
            else{
                if (rueda.isLocked()){
                    mostrarError("La rueda no se puede girar " + steps + " pasos porque esta bloqueada");
                }
                
                else{
                    mostrarError("La rueda " + wheel + " se encuentra vacia");
                }
                verify = false;
                return;
            }
        }
        
        verify = true;
    }
    
    /**
    * Pone en cada rueda el color indicado como símbolo visible, sin girarlas.
    * Falla si la cantidad de colores no coincide con el número de ruedas
    * o si algún color no existe en el catálogo.
    *
    * @param setSymbols Colores que se quieren ver, uno por cada rueda
    */
    public void spin(String[] setSymbols){
        if (setSymbols.length != wheels.size()){
            verify = false;
            mostrarError("La configuracion no coincide con el numero de ruedas.");
            return;
        }
        
        Symbol[] encontrados = new Symbol[setSymbols.length];
        for (int i = 0; i < setSymbols.length; i++){
            boolean encontrado = false;
            for (int j = 0; j < symbols.size(); j++){
                if (symbols.get(j).getColor().equals(setSymbols[i])){
                    encontrados[i] = symbols.get(j);
                    encontrado = true;
                    break;
                }
            }
            if (!encontrado){
                verify = false;
                mostrarError("El color " + setSymbols[i] + " no existe en el catalogo.");
                return;
            }
        }
    
        // si todo existe, ya aplicamos
        for (int i = 0; i < encontrados.length; i++){
            wheels.get(i).setVisible(encontrados[i]);
        }
        
        verify = true;
        
        if (isVisible){
            draw();
        }
    }
    
    //Colores reales que reconoce Circle; el resto de simbolos usa un nombre generico
    private static final String[] COLORES = {"red", "blue", "yellow", "green", "magenta", "white"};

    /**
     * Da el nombre del simbolo i: un color real si hay disponible, o un
     * nombre generico si ya no quedan colores (para n grandes).
     *
     * @param i Posicion del simbolo, desde 1
     * @return Nombre del simbolo
     */
    private String nombreSimbolo(int i){
        if (i <= COLORES.length){
            return COLORES[i - 1];
        }
        else{
            return "s" + i;
        }
    }

    /**
     * Crea una máquina con n ruedas y n símbolos, montados en cada rueda
     * y en una posición inicial al azar.
     *
     * @param n Número de ruedas y de símbolos de la máquina
     */
    public SlotMachine(int n){
        this(); //Sirve para llamar al constructor de SlotMachine.

        for (int i = 1; i <= n; i++){ //Añadir simbolos al catálogo
            addSymbol(i, nombreSimbolo(i));
        }

        for (int i = 1; i <= n; i++){ //Agregar ruedas
            addWheel(i);
            for (int j = 1; j <= n; j++){ // Agregar los n simbolos a cada rueda
                placeSymbol(i, nombreSimbolo(j));
            }
        }

        spin(); //Girar todas las ruedas
    }

}