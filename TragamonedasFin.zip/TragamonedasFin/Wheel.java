import java.util.ArrayList;

/**
 * Representa una rueda de la máquina tragaperras. Guarda los símbolos que tiene
 * montados y el símbolo que se ve en la ventanilla después de girar. Además
 * puede bloquearse para que no gire.
 * 
 * @author Santiago Hernández - Wilmar Beltran
 * @version (20 september 2026)
 */
public class Wheel {

    private ArrayList<Symbol> symbols;    
    private Symbol visible;
    private boolean locked;

    public Wheel() {
        symbols = new ArrayList<>();  
        visible = null;         
        locked = false;               
    }
    
    /**
    * Agrega un símbolo a la lista de símbolos de la rueda.
    *
    * @param symbol Símbolo que se añade a la rueda
    */
    public void mountSymbol(Symbol symbol) {
        symbols.add(symbol);
    }

    /**
     * Gira la rueda escogiendo al azar uno de sus símbolos, que pasa a ser el visible.
     * No gira si la rueda está bloqueada o si no tiene símbolos.
     *
     * @return true si la rueda giró, false si estaba bloqueada o vacía
     */
    public boolean rotate() {
        if (locked) {
            return false;
        }
        if (symbols.isEmpty()) {
            return false; 
        }
        int indice = (int) (Math.random() * symbols.size());
        visible = symbols.get(indice);
        return true;
    }

    /**
    * Consulta el color del símbolo que se ve en la ventanilla de la rueda.
    *
    * @return Color del símbolo visible, o null si la rueda todavía no ha girado
    */
    public String getVisibleColor() {
        if (visible != null){
            return visible.getColor();
        }
        else {
            return null;
        }
    }

    /**
    * Bloquea una rueda para que no pueda girar
    */
    public void lock() {
        locked = true;
    }
    
    /**
    * Desbloquea una rueda para que pueda volver a girar
    */
    public void unlock() {
        locked = false;
    }

    /**
    * Consulta si la rueda está bloqueada.
    *
    * @return true si la rueda está bloqueada, false en caso contrario
    */
    public boolean isLocked() {
        return locked;
    }
    
    /**
    * Avanza la rueda una posición sobre sus símbolos, y el siguiente pasa a ser el visible.
    * Si llega al último símbolo, vuelve al primero. Si la rueda aún no había girado,
    * se cuenta como si estuviera en el primer símbolo.
    * No avanza si la rueda está bloqueada o si no tiene símbolos.
    *
    * @return true si la rueda avanzó, false si estaba bloqueada o vacía
    */
    public boolean advance() {
        if (locked || symbols.isEmpty()){
            return false;
        }
        
        else{
            int index = symbols.indexOf(visible);
            if (index == -1) {
                index = 0;
            }
            
            index = index + 1;
            if (index >= symbols.size()){
                index = 0;
            }
            visible = symbols.get(index);
            return true;
        }
    }
    
    /**
    * Establece directamente el símbolo que se ve en la ventanilla de la rueda,
    * sin girarla. No verifica si el símbolo está montado en la rueda ni si está bloqueada.
    *
    * @param symbol Símbolo que pasa a ser el visible
    */
    public void setVisible(Symbol symbol) {
        visible = symbol;
    }
}