/**
 * Lo único que puede usar el solucionador de la maratón para tocar la
 * máquina: girar una rueda y saber cuántos colores distintos hay.
 *
 * @author (Wilmar Beltran, Santiago Hernández)
 * @version (ciclo 3)
 */
public interface TestingTool {

    /**
     * Gira una rueda.
     *
     * @param wheel Número de la rueda a girar
     * @param steps Pasos que avanza
     */
    public void spin(int wheel, int steps);

    /**
     * Cuenta los colores distintos visibles.
     *
     * @return Número de colores distintos
     */
    public int distinctSymbols();
}
