import java.util.ArrayList;

/**
 * Resuelve y simula el problema de la máquina tragaperras de la maratón.
 * solve(n) descubre a ciegas los giros que llevan al jackpot, usando solo
 * spin y distinctSymbols.
 *
 * @author (Wilmar Beltran, Santiago Hernández)
 * @version (ciclo 3)
 */
public class SlotMachineContest {

    private final TestingTool maquina;
    private final int n;
    private final ArrayList<int[]> actions;
    private int k;
    private boolean solved;

    /**
     * Crea el solucionador para una máquina ya existente.
     *
     * @param maquina Máquina a resolver
     * @param n Número de ruedas y símbolos
     */
    private SlotMachineContest(TestingTool maquina, int n) {
        this.maquina = maquina;
        this.n = n;
        this.actions = new ArrayList<>();
        this.k = maquina.distinctSymbols();
        
        if(k == 1){
            solved = true;
        }
        else{
            solved = false;
        }
    }

    /**
     * Gira una rueda y anota la acción. Único lugar del solucionador que
     * llama a spin, para no perder la cuenta.
     *
     * @param wheel Rueda a girar
     * @param steps Pasos a girar
     */
    private void turn(int wheel, int steps) {
        int pasos = steps;
        if (pasos < 0) {  //Si es negativo, osea nos piden girar hacia atras entonces
            pasos = pasos + n; 
        }
        if (pasos >= n) {
            pasos = pasos - n;
        }
        
        if (pasos == 0) {
            return;
        }
        maquina.spin(wheel, pasos);
        actions.add(new int[] {wheel, pasos});
        k = maquina.distinctSymbols();
        if (k == 1) {
            solved = true;
        }
    }

    /**
     * Fase 1: deja las n ruedas en colores distintos.
     * Cada rueda da una vuelta completa y se queda en la posición donde
     * distinctSymbols dio más alto.
     */
    private void separate() {
        for (int wheel = 1; wheel <= n; wheel++) {
            if (solved) {
                break;
            }
            if (k >= n) {
                break;
            }
            
            int[] conteos = new int[n]; //Arreglo que lleva en cada posicion el nnumero que retorna distinctSymbols
            conteos[0] = k;
            for (int paso = 1; paso < n ; paso++) {
                if (solved){
                    break;
                }
                turn(wheel, 1);
                conteos[paso] = k;
            }
            if (solved) {
                return;
            }
            int mejor = 0;
            for (int paso = 1; paso < n; paso++) {
                if (conteos[paso] > conteos[mejor]) {
                    mejor = paso;
                }
            }
            turn(wheel, mejor + 1);
        }
    }

    /**
     * Fase 2: mide la distancia de cada rueda a la rueda 1.
     * Mueve la rueda, barre la rueda 1 completa, y busca dónde
     * distinctSymbols vuelve a ser el máximo.
     *
     * @return distancias[rueda] = pasos que la separan de la rueda 1
     */
    private int[] measureOffsets() {
        int[] distancias = new int[n + 1];
        for (int rueda = 2; rueda <= n && !solved; rueda++) {
            if (solved){
                break;
            }
            turn(rueda, 1);
            if (solved) {
                break;
            }
            int[] conteos = new int[n];
            conteos[0] = k;
            for (int paso = 1; paso < n && !solved; paso++) {
                if (solved){
                    break;
                }
                turn(1, 1);
                conteos[paso] = k;
            }
            if (solved) {
                break;
            }
            turn(1, 1); // la rueda 1 vuelve a su posición

            int max = conteos[0];
            for (int paso = 1; paso < n; paso++) {
                if (conteos[paso] > max) {
                    max = conteos[paso];
                }
            }
            for (int paso = 1; paso < n; paso++) {
                if (conteos[paso] == max) {
                    distancias[rueda] = paso;
                    break;
                }
            }
            turn(rueda, -1); // deshace el paso 1 de arriba
        }
        return distancias;
    }

    /**
     * Fase 3: alinea todas las ruedas con la rueda 1.
     *
     * @param distancias Distancias medidas por measureOffsets
     */
    private void align(int[] distancias) {
        for (int rueda = 2; rueda <= n; rueda++) {
            if (solved){
                break;
            }
            turn(rueda, -distancias[rueda]);
        }
    }

    /** Ejecuta las 3 fases en orden. */
    private int[][] resolver() {
        if (!solved) {
            separate();
        }
        if (!solved) {
            int[] distancias = measureOffsets();
            if (!solved) {
                align(distancias);
            }
        }
        return actions.toArray(new int[0][]);
    }

    /**
     * Resuelve el problema para una máquina de n ruedas y n símbolos.
     *
     * @param n Número de ruedas y símbolos
     * @return Acciones {rueda, pasos} que llevan al jackpot
     */
    public static int[][] solve(int n) {
        SlotMachine sm = new SlotMachine(n);
        return solve(sm, n);
    }

    /**
     * Igual que solve(n), pero recibe la máquina ya creada (sirve para pruebas).
     *
     * @param maquina Máquina a resolver
     * @param n Número de ruedas y símbolos
     * @return Acciones {rueda, pasos} que llevan al jackpot
     */
    public static int[][] solve(TestingTool maquina, int n) {
        return new SlotMachineContest(maquina, n).resolver();
    }

    /**
     * Resuelve el problema mostrando el proceso en una máquina visible.
     *
     * @param n Número de ruedas y símbolos
     */
    public static void simulate(int n) {
        Canvas.getCanvas().eraseAll(); // por si quedaron circulos de una corrida anterior
        SlotMachine sm = new SlotMachine(n);
        sm.makeVisible();
        solve(sm, n);
    }
}
